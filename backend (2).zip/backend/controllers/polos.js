const data = require('../data.json')

exports.getpolos = (req, res) => {
    const polos_homme = data.polo_homme;
    const polos_femme = data.polo_femme;
    const polos = polos_homme.concat(polos_femme);
    console.log(polos)
    res.status(200).json({
        message: "sweat fetched successfully",
        polos
    });
}

exports.getpolo = (req, res) => {
    const id = parseInt(req.params.id);
    const polos = data.polos;

    const polo = polos.find(s => s.id === id);
    if (!polo) {
        res.status(404).send({message: "sweat not found"});
    } else { 
        res.status(200).json({
            message: "sweat found",
            polo
        })
    }
};

exports.getPolosByCategory = (req, res) => {
    const category = req.params.category;
    const polos = data[category];
    res.status(200).json({
        message: "sweat fetched successfully",
        polos
    });
}
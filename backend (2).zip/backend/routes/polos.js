const express = require('express');
const router = express.Router();
const controllers = require('../controllers/polos');

//Define routes
router.get('/polos', controllers.getpolos);
router.get('/polo/:id', controllers.getpolo);
router.get('/polos/:category', controllers.getPolosByCategory);

module.exports = router;
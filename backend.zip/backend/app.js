const express = require('express');
const cors = require('cors');
const app = express();
const port = 3000;

const poloRoutes = require('./routes/polos');
const imageRoutes = require('./routes/images');

app.use(cors({
    origin: '*'
}))

app.use(poloRoutes);
app.use(imageRoutes);

app.listen(port, () => console.log(`Server listening on ${port}`));
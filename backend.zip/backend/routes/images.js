const express = require('express');
const router = express.Router();

const fs = require('fs');

const _dirname = 'C:/Users/light/Desktop/backend/' //Chemin à changer

router.get('/image/:filename(*)', function (req, res) {
  const filename = req.params.filename;
  const filePath = _dirname + 'img/' + filename;
  fs.readFile(filePath, function (err, data) {
    if (err) {
      res.status(404).send({ error: 'Image not found', message: err });
    } else {
      res.sendFile(filePath);
    }
  });
});

module.exports = router;